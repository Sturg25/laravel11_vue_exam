<template lang="">
    <div>
        Page Not Found
        <br />
        <v-btn to="/login" variant="plain">Return</v-btn>
    </div>
</template>
<script>
export default {};
</script>
<style lang=""></style>
