export default
    function currencyUSD(value) {
    return '$' + value
}